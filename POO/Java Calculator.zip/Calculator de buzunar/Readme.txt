--How to use it--

Just simply push the buttons or press the associated keys.


R	Remove the last character.
C	Clear - (removes the last token between blanks)
CE	Clear everything.