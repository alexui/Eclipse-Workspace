//Budau Alexandru , "Politechnica" University of Bucharest

public class RunGUI {

	
	public static void main(String[] args) {

		CalculatorFrame frame = new CalculatorFrame();
		frame.setVisible(true);
	}

}
