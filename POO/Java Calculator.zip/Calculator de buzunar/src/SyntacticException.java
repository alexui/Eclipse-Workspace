
public class SyntacticException extends Exception {

	private static final long serialVersionUID = 2916684190445948659L;
	
	//TODO
}
