/**
 * enum ce contine constante care definesc tipurile de token-uri
 * @author aless
 *
 */
public enum TokenType {

	OPERATOR_BINAR,
	OPERATOR_UNAR,
	OPERAND,
	LEFTPARANTHESES,
	RIGHTPARANTHESES
}
