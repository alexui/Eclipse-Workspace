
public interface Observer{
	/**
	 * notifica eveniment pentru sirul s introdus
	 * @param s
	 * @throws SyntacticException
	 */
	void notifyEvent(String s) throws SyntacticException;
}
